enum DLButtonType { primary, secondary, tertiary, ghost }

enum DLButtonSize { xs, sm, md, lg }

enum DLButtonState { normal, hover, pressed, disabled, active }
